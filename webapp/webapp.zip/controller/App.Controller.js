sap.ui.define([
	"Mortgage-App/controller/BaseController"
], function(BaseController) {
	"use strict";

	return BaseController.extend("Mortgage-App.controller.App", {

		onInit: function () {

		}
	});
});